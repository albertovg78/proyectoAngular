import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'objNgFor'
})
export class ObjNgForPipe implements PipeTransform {

  
        
  transform(value: any, ...args: any[]): any {
    /*let palabras = value.splt(" ");
    let total = "";
    for (let i = 0; i< palabras.length; i++){
      total += palabras[i][0].toUpperCase()+ palabras[i].substring(1) + " ";
    }
    return total;*/
    //metodo senior
    
    
    let fechaTotal= "";
    for(let i=0; i < value.length; i++){
      fechaTotal += value[i].slice(0,10)
      var e = " 00:00:00"
var d = fechaTotal.concat(e)
return d
    }
    
    
  }
  

}
