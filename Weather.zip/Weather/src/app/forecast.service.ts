import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ForecastService {
  url: string;
  apiClave: string;
  constructor(private http: HttpClient) {
    this.apiClave = '3ad2bd5f53eec6329b7f291664123363'
    this.url = `https://api.openweathermap.org/data/2.5/forecast?appid=${this.apiClave}&units=metric&q=`
   }

  getForecast(nombreCiudad: string):Promise<any>{
    return this.http.get<any>(`${this.url}${nombreCiudad}`).toPromise();
    //return this.http.get<any>(`${this.url}${nombreCiudad}`);
    
  }
}
