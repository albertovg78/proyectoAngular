import { Component, OnInit } from '@angular/core';
import { ForecastService } from '../forecast.service';
import { FormsModule, FormGroup, FormControl } from '@angular/forms';
import { isObject, isArray } from 'util';
import { Key } from 'protractor';

@Component({
  selector: 'app-weather-forecast',
  templateUrl: './weather-forecast.component.html',
  styleUrls: ['./weather-forecast.component.css']
})
export class WeatherForecastComponent implements OnInit {
  arrWeatherForecast: any[];
  selectTown: FormGroup;
  ciudadValue: string;
  fechaActual: Date;
  diaActual: Number;
  mesActual: Number;
  anoActual: Number;
  fechaComparar: any;
  horaInicial:any
  coche: any[];
  coche2: Array<any>;
  coche3: any[];
  coche4: any[];
  camion: any[];
  sos: any
  x: any;
  cad: any;

  //prueba:any= [];
  weather: Object;
  constructor(private forecast: ForecastService) { 
    this.selectTown = new FormGroup({
      ciudad: new FormControl()
      
    })
    this.weather= []
    
    this.fechaActual = new Date();
    this.diaActual= this.fechaActual.getUTCDate()
    this.mesActual = this.fechaActual.getUTCMonth()+1
    this.anoActual= this.fechaActual.getUTCFullYear()
    //this.fechaComparar= `${this.anoActual}-0${this.mesActual}-${this.diaActual} 21:00:00`
    this.fechaComparar= this.fechaActual.getUTCFullYear() +"-"+("0"+ (this.fechaActual.getUTCMonth()+1))+"-"+this.fechaActual.getUTCDate();
    this.horaInicial = " 00:00:00"
    this.coche = [];
    this.coche2 = [];
    this.coche3 = [];
    this.coche4 = [];
    this.camion = [];
    this.sos= [];
    console.log(this.fechaActual)
    console.log(this.diaActual)
    console.log(this.mesActual)
    console.log(this.anoActual)
    console.log(this.fechaComparar)
    console.log(this.fechaComparar+this.horaInicial)
    
  }
  

  ngOnInit() {
    
  }
   getWeather(ciudad: string){
    this.forecast.getForecast(ciudad)
    
    .then( response => {
   this.weather = response;
   console.log(this.weather)
  //     //console.log(this.weather)
  //    //this.coche4 = Object.entries(this.weather);
  //     //console.log(typeof(this.coche4))
  //     //this.coche4 = JSON.stringify(this.weather)
  //     //console.log(this.coche4[0][1])
      
      
      
      
      
      
      
      
  //     //for( let i= 0 ; i <= this.coche4.length; i++){ 
          
  //        // this.coche3 = this.coche4[i]
  //          //console.log(this.coche3)
        
  //       // console.log(typeof(item))
  //       // this.coche3.push(item)
  //       // console.log(this.coche3)
        
  //       // if(isObject(this.coche4[item][1])){
          
  //       //   for( let item2 in this.coche4[item][1]){
            
           
            
            
            

  //       //   } 
  //       // }
  //     //}
      
      
     }).catch( err => {

     console.log(err);
    });
  }
  // getWeather(ciudad: string){
  //   this.forecast.getForecast(ciudad).subscribe(
  //     res => {
  //       this.weather = res;
  //       console.log(this.weather)
  //       console.log(res)
  //     },
  //     err => console.log(err)
  //   )
  // }
  enviarDatos(){
    
    this.ciudadValue= this.selectTown.value['ciudad'];
    
    
    if(this.ciudadValue){
      this.getWeather(this.ciudadValue);
      //console.log(this.ciudadValue, this.paisValue);
      this.ciudadValue= '';
      
      
    }else{
      alert('Porfavor, escribe algun dato')
    }
    return false;
  }
  //PRUEBA
  


}
